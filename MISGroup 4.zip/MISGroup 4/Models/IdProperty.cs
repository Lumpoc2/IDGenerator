﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;

namespace MISGroup_4.Models
{
    public class IdProperty
    {
        public object Object { get; set; }
        public int[] Size { get; set; }
        public int[] Location { get; set; }
        public string ObjectType { get; set; }

    }
}
